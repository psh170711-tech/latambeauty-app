export default function Category() {
  return (
    <div style={{ padding: 16 }}>
      <h2>Category</h2>
      <p>카테고리 페이지 (준비중)</p>
    </div>
  );
}