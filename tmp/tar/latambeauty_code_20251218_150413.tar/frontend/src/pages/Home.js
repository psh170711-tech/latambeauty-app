import React from "react";
import AppShell from "../components/layout/AppShell";
import Header from "../components/header/Header";
import SearchBar from "../components/search/SearchBar";

export default function Home() {
  return (
    <AppShell
      header={<Header title="LatamBeauty" />}
      bottomNav={<BottomNav />}
    >
      <SearchBar onSearch={(q) => console.log("search:", q)} />

      {/* 검색 도움 문구 */}
      <HintRow />

      {/* 카테고리/필터(더미) */}
      <CategoryChips />

      {/* 제품 리스트(더미) */}
      <DummyProductList />
    </AppShell>
  );
}

/** 검색 UX용 힌트 영역 (나중에 제거/개선) */
function HintRow() {
  return (
    <div
      style={{
        marginTop: 12,
        padding: "10px 12px",
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.10)",
        background: "rgba(255,255,255,0.04)",
        color: "rgba(255,255,255,0.85)",
        fontSize: 13,
        lineHeight: 1.4,
      }}
    >
      바코드 또는 제품명을 입력하세요. 예: <b>8809...</b> / <b>Beauty of Joseon</b>
    </div>
  );
}

/** 아래는 더미 컴포넌트: 다음 단계에서 분리/고도화 */
function CategoryChips() {
  // ✅ “단백질” → “화장품/성분/가격” 기준으로 변경
  const items = [
    "선크림",
    "토너/에센스",
    "세럼",
    "크림",
    "클렌저",
    "마스크팩",
    "민감피부",
    "트러블",
  ];

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 10,
        marginTop: 14,
      }}
    >
      {items.map((t) => (
        <button
          key={t}
          style={{
            padding: "12px 12px",
            borderRadius: 12,
            background: "rgba(255,255,255,0.06)",
            border: "1px solid rgba(255,255,255,0.12)",
            color: "#fff",
            textAlign: "left",
            cursor: "pointer",
          }}
          onClick={() => console.log("category:", t)}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

function DummyProductList() {
  // ✅ 더미 데이터를 “성분 유해성 점수 + 최저가” 중심으로
  const products = [
    {
      id: 101,
      brand: "Beauty of Joseon",
      name: "Relief Sun : Rice + Probiotics",
      riskLevel: "LOW",
      safetyScore: 84,
      lowestPrice: "15,900원",
      mall: "Coupang",
    },
    {
      id: 102,
      brand: "Round Lab",
      name: "1025 Dokdo Toner",
      riskLevel: "MID",
      safetyScore: 72,
      lowestPrice: "12,800원",
      mall: "Naver",
    },
    {
      id: 103,
      brand: "COSRX",
      name: "Advanced Snail 96 Mucin Essence",
      riskLevel: "LOW",
      safetyScore: 79,
      lowestPrice: "16,500원",
      mall: "11st",
    },
  ];

  return (
    <div style={{ marginTop: 18, display: "grid", gap: 12 }}>
      {products.map((p) => (
        <div
          key={p.id}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            padding: 14,
            borderRadius: 16,
            border: "1px solid rgba(255,255,255,0.12)",
            background: "rgba(0,0,0,0.22)",
            cursor: "pointer",
          }}
          onClick={() => console.log("go detail:", p.id)}
        >
          {/* 썸네일 자리(나중에 image_url 연결) */}
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: 14,
              background: "rgba(255,255,255,0.08)",
            }}
          />

          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{p.brand}</div>
            <div
              style={{
                fontSize: 16,
                fontWeight: 800,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {p.name}
            </div>

            {/* 성분/유해성 요약 라인 */}
            <div style={{ marginTop: 6, display: "flex", gap: 10, flexWrap: "wrap" }}>
              <Badge label={`Risk: ${p.riskLevel}`} />
              <Badge label={`Safety: ${p.safetyScore}`} />
            </div>
          </div>

          {/* 가격/최저가 */}
          <div style={{ textAlign: "right" }}>
            <div style={{ fontWeight: 900 }}>{p.lowestPrice}</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>최저가 · {p.mall}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Badge({ label }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: 12,
        border: "1px solid rgba(255,255,255,0.14)",
        background: "rgba(255,255,255,0.06)",
        color: "rgba(255,255,255,0.9)",
      }}
    >
      {label}
    </span>
  );
}

function BottomNav() {
  // ✅ “저점/계산기” → 서비스 구조 맞춤
  const items = ["홈", "카테고리", "스캔", "즐겨찾기", "마이"];

  return (
    <nav
      style={{
        position: "sticky",
        bottom: 0,
        borderTop: "1px solid rgba(255,255,255,0.08)",
        background: "rgba(11,15,20,0.85)",
        backdropFilter: "blur(10px)",
        padding: "10px 12px",
        display: "grid",
        gridTemplateColumns: "repeat(5, 1fr)",
        gap: 8,
      }}
    >
      {items.map((t) => (
        <button
          key={t}
          style={{
            border: "none",
            background: "transparent",
            color: "rgba(255,255,255,0.85)",
            cursor: "pointer",
            padding: "8px 0",
            borderRadius: 10,
          }}
          onClick={() => console.log("nav:", t)}
        >
          {t}
        </button>
      ))}
    </nav>
  );
}