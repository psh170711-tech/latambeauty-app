import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { fetchProductById } from "../api/productApi";

import ProductCard from "../components/ProductCard";
import PriceTable from "../components/PriceTable";
import IngredientRiskPanel from "../components/IngredientRiskPanel";

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const data = await fetchProductById(id);
        setProduct(data);
      } catch (err) {
        setError("제품 정보를 불러올 수 없습니다.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  if (loading) return <p>⏳ 로딩중...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;
  if (!product) return <p>제품 정보가 없습니다.</p>;

  return (
    <div style={{ padding: 24, maxWidth: 820, margin: "0 auto" }}>
      {/* 1️⃣ 제품 기본 정보 */}
      <ProductCard product={product} />

      {/* 2️⃣ 성분 유해성 분석 (핵심 차별점) */}
      <IngredientRiskPanel
  	productName={product?.name}
  	riskScore={product?.risk_score}
  	safetyScore={product?.safety_score}
  	riskLevel={product?.risk_level || "TBD"}
      />

      {/* 3️⃣ 가격 비교 */}
      <PriceTable prices={product.offers || []} />
    </div>
  );
};

export default ProductDetail;