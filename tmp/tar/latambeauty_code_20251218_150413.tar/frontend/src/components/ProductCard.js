import { useNavigate } from "react-router-dom";

export default function ProductCard({ product }) {
  const navigate = useNavigate();

  return (
    <div
      onClick={() => navigate(`/products/${product.id}`)}
      style={{
        cursor: "pointer",
        padding: 16,
        borderRadius: 16,
        border: "1px solid rgba(255,255,255,0.12)",
        display: "flex",
        gap: 14,
      }}
    >
      <img
        src={product.image}
        alt={product.name}
        style={{ width: 64, height: 64, borderRadius: 12 }}
      />
      <div style={{ flex: 1 }}>
        <div style={{ opacity: 0.7, fontSize: 12 }}>{product.brand}</div>
        <div style={{ fontSize: 16, fontWeight: 800 }}>{product.name}</div>
        <div style={{ fontSize: 12 }}>
          Risk: {product.risk.level} · Safety {product.risk.safetyScore}
        </div>
      </div>
      <div style={{ fontWeight: 900 }}>
        {product.price.toLocaleString()}원
      </div>
    </div>
  );
}