import React from "react";
import "./AppShell.css";

export default function AppShell({ header, children }) {
  return (
    <div className="app-shell">
      {header}
      <main>{children}</main>
    </div>
  );
}