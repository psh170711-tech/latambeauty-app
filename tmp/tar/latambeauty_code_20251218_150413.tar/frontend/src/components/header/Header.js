import React from "react";
import "./Header.css";

export default function Header() {
  return (
    <header className="lb-header">
      {/* 왼쪽: 로고 + 서비스명 */}
      <div className="lb-headerLeft">
        <div className="lb-logoDot" />
        <div className="lb-title">LatamBeauty</div>
      </div>

      {/* 오른쪽: 알림 */}
      <div className="lb-headerRight">
        <button className="lb-iconBtn">🔔</button>
      </div>
    </header>
  );
}