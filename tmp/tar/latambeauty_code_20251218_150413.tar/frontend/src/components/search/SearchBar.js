import React, { useState } from "react";
import "./SearchBar.css";

export default function SearchBar({ onSearch }) {
  const [query, setQuery] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    onSearch?.(query);
  };

  return (
    <form className="search-wrap" onSubmit={submit}>
      <input
        className="search-input"
        type="text"
        placeholder="바코드 또는 제품명을 검색하세요"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button className="search-btn" type="submit">
        검색
      </button>
    </form>
  );
}